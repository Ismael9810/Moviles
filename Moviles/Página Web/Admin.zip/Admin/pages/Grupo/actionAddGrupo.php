<?php 
$Resultado= array(); 
if (isset($_POST['nombre']) && isset($_POST['descripcion']) && isset($_POST['accion'])) {
	if ($_POST['accion']=='agregar') {
		$Con = mysqli_connect("localhost", "root", "", "database_mov"); 
		$grup = $_POST['nombre']; 
		$descripcion = $_POST['descripcion']; 
		$QueryAgregar = "INSERT INTO grupo (nombre, descripcion) VALUES ('".$grup."', '".$descripcion."')"; 
		if (mysqli_query($Con, $QueryAgregar)){
			$idNew = mysqli_insert_id($Con); 
			$Resultado['estado'] = 1; 
			$Resultado['mensaje'] = "Grupo agregado con éxito"; 
			$Resultado['id'] = $idNew; 
		}else{
			$Resultado['estado'] = 0; 
			$Resultado['mensaje'] = "Ocurrió un error inesperado"; 
		}
		mysqli_close($Con); 
	}else{
		$Resultado['estado']=0; 
		$Resultado['mensaje']="Accion no válida"; 
	}
}else{
	$Resultado['estado']=0; 
	$Resultado['mensaje']= "Faltan parámetros"; 
}
echo json_encode($Resultado); 
?>