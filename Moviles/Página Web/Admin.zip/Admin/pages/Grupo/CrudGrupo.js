var idEliminar =0; 
var idActualizar =0; 

function addGrupo(){
	var tipo; 
	var id=0;
	var descripcion; 
	var botonActualizar; 
	var botonEliminar; 

	var tabla = $('#example1').DataTable(); 
	tipo = $('#grupo').val(); 
	descripcion = $('#descripcion').val(); 
	botonActualizar = '<td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-primary" onclick="IdentificaActualizar('+id+')">E</button></td>';
	botonEliminar = '<td><button type= "button" class= "btn btn-danger" data-toggle = "modal" data-target ="#modal-danger" onclick = "IdentificaEliminar('+id+')">X</button></td>';
	
	$.ajax({
		url: 'actionAddGrupo.php',
		type: 'POST',
		data: {nombre: tipo, descripcion: descripcion, accion: 'agregar'}, 
		success: function (Resultado) {
			var resJSON = JSON.parse(Resultado); 
			if (resJSON.estado==1){
				id = resJSON.id; 
				tabla.row.add([
					id, 
					tipo, 
					descripcion, 
					botonActualizar, 
					botonEliminar
					]).draw().node().id= "row_"+id; 
			}
			alert(resJSON.mensaje); 
		},
		error: function (data){
			alert("Ocurrio un error");
		}
	});
}

function identificaEliminar(id){
	idEliminar=id; 
}

function deleteGrupo() {
	var tabla= $('#example1').DataTable(); 

	$.ajax({
		url:"actionDeleteGrupo.php",
		type: "POST", 
		data:{id: idEliminar, accion:'eliminar'},
		success: function (Resultado) {
			var res = JSON.parse(Resultado); 
			if (res.estado==1){
				tabla.row("#row_" +idEliminar).remove().draw(); 
			}
			alert(res.mensaje); 
		},
		error: function(data){
			alert("ocurrio un error"); 
		}
	}); 
}

function identificaActualizar(id) {
	idActualizar=id; 
}

function updateGrupo() {
	var updateGrupo; 
	var updateDescripcion; 
	var id; 
	var tabla; 

	updateGrupo = document.getElementById("nombre").value;
	updateDescripcion = document.getElementById("iddescripcion").value; 
	tabla = $("#example1").DataTable(); 
	id=idActualizar; 

	$.ajax({
		url: 'actionUpdateGrupo.php',
		type: 'POST', 
		data: {nombre:updateGrupo, descripcion:updateDescripcion, id:id, accion:'actualizar'},
		success: function (Resultado) {
			var resJSON = JSON.parse(Resultado); 
			if (resJSON.estado==1) {
				var temp = tabla.row('#row_'+id).data(); 
				temp[1] = updateGrupo; 
				temp[2] = updateDescripcion; 

				tabla.row('#row_'+id).data(temp).draw();
				}
				alert(resJSON.mensaje); 
			},
			error: function (data) {
				alert("Ocurrio un error"); 
			}
	}); 
}	

function readGrupo() {
	alert ("Muestra todas las prácticas");
}