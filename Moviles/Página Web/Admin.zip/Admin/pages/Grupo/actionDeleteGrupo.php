<?php  
	$Resultado = array();

	if (isset($_POST['id']) && isset($_POST['accion'])) {
		if ($_POST['accion'] == "eliminar") {
			$id = $_POST['id']; 
			$Con = mysqli_connect("localhost", "root", "", "database_mov"); 
			$QueryEliminar = "DELETE FROM grupo WHERE id=".$id;  
				if(mysqli_query($Con, $QueryEliminar)){
					$Resultado['estado']=1; 
					$Resultado['mensaje']="Práctica eliminada con éxito"; 
				}else{
					$Resultado['estado']=0; 
					$Resultado['mensaje']= "Ocurrio un error inesperado"; 
				}
		mysqli_close($Con); 
		}else{
			$Resultado['estado']=0; 
			$Resultado['mensaje']="Sólo se permite eliminar"; 
		}
	}else{
		$Resultado['estado']=0; 
		$Resultado['mensaje']="Falta id y/o acción"; 
	}

echo json_encode($Resultado);
?>