<?php
	$Resultado= array();
	if (isset ($_POST['nombre']) && isset($_POST['descripcion']) && isset($_POST['id']) && isset($_POST['accion'])){
		if ($_POST['accion']=='actualizar') {
			$Con = mysqli_connect("localhost","id15256677_haidejaqui","[P#rEn9ydXHCn4\A","id15256677_datab_proyectomov");
			//$Con = mysqli_connect("localhost","id15256677_haidejaqui","[P#rEn9ydXHCn4\A","id15256677_datab_proyectomov");
			//$Con = mysqli_connect("localhost","root","","database_mov");
			$grup = $_POST['nombre'];
			$descrip = $_POST['descripcion']; 
			$id = $_POST['id']; 
			$QueryActualizar = "UPDATE grupo SET nombre='".$grup."', descripcion ='".$descrip."' WHERE idGrupo=" .$id; 
			if (mysqli_query($Con, $QueryActualizar)) {
				$Resultado['estado']=1; 
				$Resultado['mensaje']="La práctica se actualizó con éxito"; 
			}else{
				$Resultado['estado']=0; 
				$Resultado['mensaje']="Ocurrió un error inesperado"; 
			}
			mysqli_close($Con); 
		}else{
			$Resultado['estado']=0; 
			$Resultado['mensaje']="Accion no válida"; 
		}
	}else{
		$Resultado['estado']=0; 
		$Resultado['mensaje']="Faltan parámetros"; 
	}

echo json_encode($Resultado); 
?>