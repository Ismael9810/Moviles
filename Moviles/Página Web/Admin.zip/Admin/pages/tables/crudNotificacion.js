var idEliminar =0; 
var idActualizar =0; 

function addNotify(){
	var id = 3; 
	var titulo; 
	var descripcion; 
	var grupo;
	 
	var botonActualizar; 
	var botonEliminar; 

	var tabla = $('#example1').DataTable(); 
	titulo = $('#Asunto').val();
	descripcion = $('#descripcion').val(); 
	grupo = $('#selec').val(); 

	$.ajax({
		url: 'actionAddNotify.php',
		type: 'POST',
		data: {titulo:titulo, descripcion:descripcion,  grupo:grupo, accion:'agregar'},
		success: function (Resultado) {
			//alert(Resultado);
			var resJSON = JSON.parse(Resultado); 
			if (resJSON.estado==1){
				id = resJSON.id; 
				tabla.row.add([
					id,
					titulo, 
					descripcion,
					grupo
					]).draw().node().id= "row_"+id; 
			}
			alert(resJSON.mensaje); 
		},
		error: function (data){
			alert("Ocurrio un error");
		}
	});
}

function identificaEliminar(id){
	idEliminar=id; 
}

function deleteNotify() {
	var tabla= $('#example1').DataTable(); 

	$.ajax({
		url:"actionDeleteGrupo.php",
		type: "POST", 
		data:{id: idEliminar, accion:'eliminar'},
		success: function (Resultado) {
			var res = JSON.parse(Resultado); 
			if (res.estado==1){
				tabla.row("#row_" +idEliminar).remove().draw(); 
			}
			alert(res.mensaje); 
		},
		error: function(data){
			alert("ocurrio un error"); 
		}
	}); 
}

function identificaActualizar(id) {
	idActualizar=id; 
}

function updateNotify() {
	var updateGrupo; 
	var updateDescripcion; 
	var id; 
	var tabla; 

	updateGrupo = document.getElementById("nombre").value;
	updateDescripcion = document.getElementById("iddescripcion").value; 
	tabla = $("#example1").DataTable(); 
	id=idActualizar; 

	$.ajax({
		url: 'actionUpdateGrupo.php',
		type: 'POST', 
		data: {nombre:updateGrupo, descripcion:updateDescripcion, id:id, accion:'actualizar'},
		success: function (Resultado) {
			var resJSON = JSON.parse(Resultado); 
			if (resJSON.estado==1) {
				var temp = tabla.row('#row_'+id).data(); 
				temp[1] = updateGrupo; 
				temp[2] = updateDescripcion; 

				tabla.row('#row_'+id).data(temp).draw();
				}
				alert(resJSON.mensaje); 
			},
			error: function (data) {
				alert("Ocurrio un error"); 
			}
	}); 
}	

function readNotify() {
	alert ("Muestra todas las prácticas");
}

function enviarMensaje(titulo, descripcion){

	$.ajax({
		url: 'actionAddNotify.php',
		type: 'POST',
		data: {grupo:grupo},
		success: function (Resultado){
			var data = JSON.parse(Resultado);
			if (data.success == "1"){
				for (var x=0; x<data.agrupamiento.length; x++){
					$.ajax({
						url: 'EnviarNoti.php',
						type: 'POST',
						data: {titulo:titulo, descripcion:descripcion, idGru:json.agrupamiento[x].usuario_idUsuario},
						success: function(Resultado){
						}
					})
				}

			}else{
				alert("Error al enviar mensaje"); 
			}
		}
	});
}