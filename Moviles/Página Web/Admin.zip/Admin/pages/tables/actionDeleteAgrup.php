<?php  
	$Resultado = array();

	if (isset($_POST['id']) && isset($_POST['accion'])) {
		if ($_POST['accion'] == "eliminar") {
			$id = $_POST['id']; 
			$Con = mysqli_connect("localhost","id15256677_haidejaqui","[P#rEn9ydXHCn4\A","id15256677_datab_proyectomov");
			//$Con = mysqli_connect("localhost","id15256677_haidejaqui","[P#rEn9ydXHCn4\A","id15256677_datab_proyectomov");
			//$Con = mysqli_connect("localhost","root","","database_mov");
			$QueryEliminar = "DELETE FROM agrupamiento WHERE idAgrupamiento=".$id;  
				if(mysqli_query($Con, $QueryEliminar)){
					$Resultado['estado']=1; 
					$Resultado['mensaje']="Práctica eliminada con éxito"; 
				}else{
					$Resultado['estado']=0; 
					$Resultado['mensaje']= "Ocurrio un error inesperado"; 
				}
		mysqli_close($Con); 
		}else{
			$Resultado['estado']=0; 
			$Resultado['mensaje']="Sólo se permite eliminar"; 
		}
	}else{
		$Resultado['estado']=0; 
		$Resultado['mensaje']="Falta id y/o acción"; 
	}

echo json_encode($Resultado);
?>