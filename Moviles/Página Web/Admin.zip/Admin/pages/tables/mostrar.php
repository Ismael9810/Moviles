<?php 
$Resultado= array(); 

		$id = $_POST['idusuarioextra']; 
		//$Con = mysqli_connect("localhost","id15256677_haidejaqui","[P#rEn9ydXHCn4\A","id15256677_datab_proyectomov");
		//$Con = mysqli_connect("localhost","root","","database_mov");
		$Con = mysqli_connect("localhost","id15256677_haidejaqui","[P#rEn9ydXHCn4\A","id15256677_datab_proyectomov");

		$QueryAgregarU = "SELECT * FROM agrupamiento, usuario WHERE agrupamiento.usuario_idUsuario=usuario.idUsuario";
		if (mysqli_query($Con, $QueryAgregarU)){
			$idNew = mysqli_insert_id($Con); 
			$Resultado['estado'] = 1; 
			$Resultado['mensaje'] = "Grupo agregado con éxito"; 
			$Resultado['id'] = $idNew; 
		}else{
			$Resultado['estado'] = 0; 
			$Resultado['mensaje'] = "Ocurrió un error inesperado"; 
		}
		mysqli_close($Con); 
	

echo json_encode($Resultado); 
?>

