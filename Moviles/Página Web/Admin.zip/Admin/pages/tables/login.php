 <?php


if (isset($_SESSION['user_id'])) {
  header('Location: login');
}

require 'conexion.php';

if (!empty($_POST['email']) && !empty($_POST['password'])) {
  $usuario = 121179;
 $clave = 121179;
  $message = '';
  if ( ($_POST['email'] == $usuario) && password_verify($_POST['password']==$clave)) {
    $_SESSION['user_id'] = $results['id'];
    header('Location: apihjafbasededatos.000webhostapp.com/crud/Admin/pages/Menu_Inicio.html');
  } else {
    $message = 'Upss, el correo o la contraseña no coinciden';
  }
}

?>




<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Inicio de Sesion</title>
  <link href="https://fonts.googleapis.com/css2?family=Mirza&display=swap" rel="stylesheet">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" 
  integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <link rel="stylesheet" href="assets/css/style.css">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="../../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../../bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../../bower_components/Ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../../plugins/iCheck/square/blue.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  

</head>
<body class="hold-transition login-page">

  <h1></h1>
  <br>
  <br>
  <br>
  <h1><b>No</b>ti<b>P</b>ush<b>U</b>PIIZ</h1>

    <?php if(!empty($message)) : ?>
      <p> <?= $message ?></p>
    <?php endif; ?>

    <div class="container">
      <div class="row justify-content-center pt-.5 mt-.5 m-1">
        <div class="col-md-6 col-sm-8 col-xl-4 col-lg-5 formulario">
          <form action="login.php" method="POST">
            
            <div class="form-group has-feedback">
              <input type="text" class="form-control " placeholder="Usuario" name="email">
              <!--span class="menu-icon fa fa fa-user form-control-feedback"></span-->
            </div>
            <div class="form-group has-feedback">
             <input type="password" class="form-control" placeholder="Clave" name="password">
              <!--span class="glyphicon glyphicon-lock form-control-feedback"></span-->
              <br>


          
              </div>

            <div class="form-group mx-sm-4 pb-2">
              <input type="submit" class="btn btn-block ingresar" value="Iniciar sesión">
            </div>

          </form>
        </div>
      </div>
    </div>




  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

<!-- jQuery 3 -->
<script src="../../bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="../../plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' /* optional */
    });
  });
</script>
</body>
</html>