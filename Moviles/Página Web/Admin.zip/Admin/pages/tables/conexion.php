<?php

$server = 'localhost';
$username = 'id15256677_haidejaqui';
$password = '[P#rEn9ydXHCn4\A';
$database = 'id15256677_datab_proyectomov';

try {

 // $Con = mysqli_connect("localhost","id15256677_haidejaqui","[P#rEn9ydXHCn4\A","id15256677_datab_proyectomov");
  $conn = new PDO("mysql:host=$server;dbname=$database;", $username, $password);
  		//echo "Exito ";
} catch (PDOException $e) {
  die('Connection Failed: ' . $e->getMessage());
}

?>