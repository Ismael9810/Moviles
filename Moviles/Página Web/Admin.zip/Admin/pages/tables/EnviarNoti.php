<?php
	$titulo = $_POST['titulo'];
	$descrip = $_POST['descripcion']; 
	$grupo = $_POST['idGru']; 

	$notificacion = array();
	$notificacion['titulo'] = $titulo; 
	$notificacion['body'] = $descrip; 

	$nueva = $grupo; 

	$fields = array(
		'to' => '/topics/'. "ID" .$nueva,
		'notificacion' => $notificacion
	);

	$url = 'https://fcm.googleapis.com/fcm/send';

    $headers = array (
                //colocar el token
            'Authorization: key= AAAAdlpqqYw:APA91bHW_YE7VkP2xMgHm7yWWaQYYiGP5DS827djEMriT4lPPLmBA-wWirnxwNyvmkGARSS63xOpZXReHXNZzdFKIG8EgQx2sZzVYdMPCqR77IuNO62Eoq7LSoOgaVF9GxoPhC-z9k8B',
            'Content-Type: application/json'
    );

    $ch = curl_init ();

    //curl_setopt ( $ch, CURLOPT_URL, $url );
    curl_setopt ( $ch, CURLOPT_POST, true );
    curl_setopt ( $ch, CURLOPT_HTTPHEADER, $headers );
    curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );

	curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, false);    
    curl_setopt ( $ch, CURLOPT_POSTFIELDS, json_encode($fields));
    echo json_encode($fields);
    $result = curl_exec ( $ch );
    echo $result;
    curl_close ( $ch );
}
?>