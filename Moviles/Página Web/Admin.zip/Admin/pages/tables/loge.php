<?php
	

	final class Log {
		function loge($usuario, $contra){
			require 'conexion.php';

			$sql = "SELECT * FROM login WHERE usuario = ? AND contra = md5(?)";
			$sentencia_select = $conn->  prepare($sql);
			$sentencia_select->bindParam(1,$usuario);
			$sentencia_select->bindParam(2,$contra);
			$sentencia_select->execute();
			$conteo = $sentencia_select->rowCount();

			if($conteo >0){
				return true;
			}else{
				return false;
			}
		}

		
		function mostrar1(){
			require 'conexion.php';

			//mostrar la cabeza de la tabla
			$sql = "SHOW COLUMNS FROM usuario";
			$sentencia_select = $conn->prepare($sql);
			$sentencia_select->execute();
			$conteo = $sentencia_select->rowCount();
			$regresar="<table id='example2' class='table table-bordered table-hover'><thead>";
			if($conteo > 0){
				$regresar .= "<th> Id </th>";
				$regresar .= "<th> Nombre </th>";
				$regresar .= "<th> Funcion </th>";
				$regresar .= "<th>  </th>";

				//mostrar el contenido de la tabla
				$regresar .= "</thead><tbody style='cursor:pointer'>";
				$regresar .= $this->datos1();
				$regresar .= "</tbody></table>";
			}
			else{
				
			}
			return $regresar;
		}

		function datos1(){

			//$Con = mysqli_connect("localhost", "root", "", "database_mov");

			require 'conexion.php';
			  
			$regresar = "";
			$sql2  = "SELECT * FROM agrupamiento, usuario WHERE agrupamiento.usuario_idUsuario=usuario.idUsuario";
			$sql2  = "SELECT * FROM agrupamiento, usuario WHERE agrupamiento.usuario_idUsuario=usuario.idUsuario";
			$sentencia_select2 = $conn->prepare($sql2);
			$sentencia_select2->execute();
			$conteo2 = $sentencia_select2->rowCount();
                
				if($conteo2 > 0){
					foreach ($sentencia_select2 as $filas2) {
						$id = $filas2["idAgrupamiento"];
						$usuario = $filas2["nombreCom"];
						$tipo = $filas2["tipo"];
						$script = "onclick='seleccionar(this,$id)'";
						$regresar .= "<tr $script>";
						$regresar .= "<td style='display:none'><input type='checkbox' name='check[]' id='chk$id' value='$id'></td>";
						$regresar .= "<td>$id</td>";
						$regresar .= "<td>$usuario</td>";
						$regresar .= "<td>$tipo</td>";
                        
                        $regresar .= "<td><center><button type='button'class='menu-icon fa fa-trash btn' data-toggle='modal' data-target='#modal-eliminarA' onclick='identificaEliminar(".$id.")'></button></center></td>";
					}
				}
			
			return $regresar;
		}



		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	}
?>