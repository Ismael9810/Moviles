<?php

$Resultado = array();
//print_r($_POST); //Este no va, para que le genere bien el JSON
//echo $Resultado;
if (isset($_POST['titulo']) && isset($_POST['descripcion']) && isset($_POST['grupo']) && isset($_POST['accion'])) {
	# code...
	if ($_POST['accion']=='agregar') {
		# code...
		$Con = mysqli_connect("localhost","id15256677_haidejaqui","[P#rEn9ydXHCn4\A","id15256677_datab_proyectomov");
		//$Con = mysqli_connect("localhost","root","","database_mov");
		$nombre = $_POST['titulo'];
		$descripcion = $_POST['descripcion'];
		date_default_timezone_set('America/Mexico_city'); 
        $fecha = date("d/m/y H:i:s"); 
		$grupo=$_POST['grupo'];
		$QueryAgregar ="INSERT INTO notificacion(titulo,descripcion, fecha, grupo_idGrupo) VALUES ('".$nombre."','".$descripcion."', '".$fecha."',".$grupo.")";
		//echo $QueryAgregar;
		if (mysqli_query($Con,$QueryAgregar)) {
			# code...
			$idNew = mysqli_insert_id($Con);
			$Resultado['estado']=1;
			$Resultado['mensaje']="Notificación agregada con éxito";
			$Resultado['id']=$idNew;
		}else{
			$Resultado['estado']=0;
			$Resultado['mensaje']="Ocurrió un error desconocido";
		}
		mysqli_close($Con);
	}else{
		$Resultado['estado']=0;
		$Resultado['mensaje']="Acción no válida";
	}
}
else{
	$Resultado['estado']=0;
	$Resultado['mensaje']="Faltan parámetros";
}
echo json_encode($Resultado);
?>