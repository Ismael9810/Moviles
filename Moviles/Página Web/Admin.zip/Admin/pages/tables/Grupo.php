<?php  

require("conexion.php");
  require("logear.php");
    require("loge.php");

  $obj = new Login();
   $obj1 = new Log();

$bandRegistros=0; 
$Con = mysqli_connect("localhost","id15256677_haidejaqui","[P#rEn9ydXHCn4\A","id15256677_datab_proyectomov");
//$Con = mysqli_connect("localhost","root","","database_mov");
if (mysqli_connect_errno()){
  # code...
  echo "Error: ".mysqli_connect_errno();
}else{
  $QueryGrupo= "SELECT * FROM grupo"; 
  $ResultadoGrupo= mysqli_query($Con, $QueryGrupo); 

  $QueryUsu="SELECT * FROM usuario";
  $ResultadoUsu= mysqli_query($Con, $QueryUsu); 

  $renglonGrupo = mysqli_fetch_array($ResultadoUsu);
  $bandRegistros=1; 
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Grupo</title>

  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="WebBurger/public/js/mostrarContrasena.js"></script>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="../../bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../../bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini" style="background-image: url('img/blanco.jpg');">
<div class="wrapper">
  <header class="main-header">
    <!-- Logo -->
   <a href="../Menu_Inicio.html" class="logo" style="background-image: url('img/azul.jpg');">
       <span class="logo-mini"><b>No</b>ti<b>P</b>ush<b>U</b>PIIZ</span>
       <span class="logo-lg"><b>No</b>ti<b>P</b>ush<b>U</b>PIIZ</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
   <nav class="navbar navbar-static-top" style="background-image: url('img/azulG.png');">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-target="modal-default">
              <span class="hidden-xs">Salir</span>
            </a>
            <ul class="dropdown-menu">
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-right">
                  <a href="login.php" class="btn btn-default btn-flat" data-target="modal-default">Salir</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
      </div>
      <!-- search form -->
      
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MENÚ</li>
        
        
         <!--li >
        <a href="../Menu_Inicio.php">
          <i class="fa fa-fw fa-book"></i>
          <span>Inicio</span>
          <span class="pull-right-container">                                               
          </span>
         </a>     
      </li-->
          <li>
          <a href="Notificaciones.php">
         <i class="fa fa-fw fa-file-text-o"></i> <span>Notificaciones</span>
         <span class="pull-right-container">
           </span>
         </a>
           </li>
         <li>
        <a href="Grupo.php">
     <i class="fa fa-fw fa-credit-card"></i> <span>Agrupamientos</span>
      <span class="pull-right-container">
       </span>
      </a>
      </li>
     <li>
      <a href="login.php">
      <i class="fa fa-fw fa-folder-o"></i> <span>Salir</span>
     <span class="pull-right-container">
      </span>
        </a>
       </li>
      </ul>  
  </aside>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Grupo
      </h1>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <!--h3 class="box-title">Grupo</h3-->
              <h3 align="right"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal-nuevo"  style="background-image: url('img/azulG.png')";>Nuevo</button></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <!--th>Id</th-->
                  <th width="200">Nombre</th>
                  <th width="200">Descripción</th>
                  <th width="200">Acciones</th>
                 
                </tr>
                </thead>
                <tbody>
                   
                <tr>
                  <td></td>
                  <td></td>
                  <td>

                 <center>
                   <?php
                   if ($bandRegistros==1) {
                    while ($renglonGrupo = mysqli_fetch_array($ResultadoGrupo)) {
                       echo "<tr id= 'row_".$renglonGrupo['idGrupo']."'>";
                        //echo "<td>".$renglonGrupo['idGrupo']."</td>";
                        echo "<td>".$renglonGrupo['nombre']."</td>";
                        echo "<td>".$renglonGrupo['descripcion']."</td>";
                        echo '<td> <button type= "button" name="guardarAsigna" class="menu-icon fa fa-group btn " data-toggle="modal" data-target="#modal-primary" onclick = "identificaAsignar('.$renglonGrupo["idGrupo"].')"></button></td>'; 

                        echo '<td> <button type= "button" class="menu-icon fa fa-edit btn" data-toggle="modal" data-target="#modal-editar" onclick = "identificaActualizar('.$renglonGrupo["idGrupo"].')"></button></td>'; 

                        echo '<td><button type= "button"  class=" btn btn-default menu-icon fa fa-trash btn" data-toggle = "modal" data-target ="#modal-dange" onclick = "identificaEliminar('.$renglonGrupo["idGrupo"].')"></button></td>';
                        echo "</tr>";


                        //<button type="button" class="btn btn-default" data-dismiss="modal" onclick="deleteGrupo();">Eliminar</button>
                      }
                   }
                ?>
                 </center>
                </td>

                </tr>
             


                </tbody>
                

              </table>

              
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<div class="content-wrapper">
  <div class="modal fade" id="modal-default">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Confirmación de Salida</h4>
              </div>
              <div class="modal-body">
                <p>¿Desea Salir?&hellip;</p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary">Salir</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
      </div>

<div class="modal modal-primary fade" id="modal-editar"> <!--dos-->
    <div class="modal-dialog" style="size: 90%">
            <div class="modal-content">
             <div class="modal-header"  style="background-image: url('img/azulG.png')";>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                  <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title" >Editar </h4>
               
              </div>
              

                   <section class="content">
                       
                          <div class="col-xs-12">
                            
                              
                              <!-- /.box-header -->

                      <div class="box box-solid">
                    
                        <h3 class="box-title">Nombre</h3>
                     
                      <!-- /.box-header -->
                     
                        <!--Aquí van los inputs-->
                        <input type="text" class="form-control" placeholder="Digite un nombre" id="nombre">
                      
                      <!-- /.box-body -->
                    </div>
                              
                      <div class="box box-solid">
                      
                        <h3 class="box-title">Descripción</h3>
                    
                      <!-- /.box-header -->
                     
                        <!--Aquí van los inputs-->
                        <input type="text" class="form-control" placeholder="Descripción" id="iddescripcion">
                     
                      <!-- /.box-body -->
                    </div>
                            <button type="submit" class="btn btn-primary pull-right" name="guardar" align="right" style="background-image: url('img/azulG.png')" onclick="updateGrupo();";>Actualizar</button>


                  <button type="submit" class="btn btn-primary pull-left" name="guardar" data-dismiss="modal" style="background-image: url('img/azulG.png')";>Cancelar</button>
                   <br></br>
                              <!-- /.box-body -->

                          
                          </div>


               </section>
    
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
  </div>
<div class="modal modal-primary fade" id="modal-nuevo">
          <div class="modal-dialog" >
            <div class="modal-content">
              <div class="modal-header"  style="background-image: url('img/azulG.png')";>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" >
                  <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title" >Nuevo Grupo</h4>
               
              </div>

             <div class="content">

                

                   <section class="content">
                       
                          <div class="col-xs-12">
                            
                              
                              <!-- /.box-header -->

                      <div class="box box-solid">
                    
                        <h3 class="box-title">Nombre</h3>
                     
                      <!-- /.box-header -->
                     
                        <!--Aquí van los inputs-->
                        <input type="text" class="form-control" placeholder="Digite un nombre" id="grupo">
                      
                      <!-- /.box-body -->
                    </div>
                              
                      <div class="box box-solid">
                      
                        <h3 class="box-title">Descripción</h3>
                    
                      <!-- /.box-header -->
                     
                        <!--Aquí van los inputs-->
                        <input type="text" class="form-control" placeholder="Descripción" id="descripcion">
                     
                      <!-- /.box-body -->
                    </div>
                             <button type="submit" class="btn btn-primary pull-right" name="guardar" align="right" style="background-image: url('img/azulG.png')" onclick="addGrupo();">Guardar</button>


                  <button type="submit" class="btn btn-primary pull-left" name="guardar" data-dismiss="modal" style="background-image: url('img/azulG.png')";>Cancelar</button>
                   <br></br>
                              <!-- /.box-body -->

                          
                          </div>
                   
                      <!-- /.content -->
                  <br></br>
                     

               </section>
               
                  </div>
                </div>
               
                <div class="control-sidebar-bg">
                  
                </div>
             
               </div>
              </div>
  </div>





<div class="content-wrapper">
  <div class="modal modal-danger fade" id="modal-warning">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class=" fa-danger">ADVERTENCIA</h4>
              </div>
               <div class="modal-body">
                <p> La confirmación eliminará todos los datos, ¿Desea eliminarlos?&hellip;</p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-default"  data-dismiss="modal" onclick="deleteGrupo();">Eliminar</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
      </div>



  <div class="modal  fade" id="modal-primary" > <!--uno-->
     <div class="row" >
    <div class="modal-dialog" >
            <div class="modal-content">
              <div class="modal-header"  style="background-image: url('img/azulG.png')";>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
               <h1>
                      <font color="#FFFFFF">
                        Asignar grupo
                        </font>
                    </h1>
              </div>
        
                
                   <section class="content">
                       
                          <!--div class="col-xs-12"-->
                            <div class="box">
                              <div class="box-header">
                              </div>
                              <!-- /.box-header -->
                            <form class="form-horizontal" method="POST">
                <div class="table-responsive">
                  <?=$obj->mostrar()?>
                  
                </div>

                <div class="form-group">
                  <div class="col-md-6 col-md-offset-3">
                                
                  </div>
                </div>
                
              </form>

                           
 <script>
      function seleccionar(tr,value){
        $(function(){
          if($("#chk"+value).attr("checked") == "checked"){
            $("#chk"+value).prop('checked', false).removeAttr('checked');
            $(tr).css("background-color","#FFFFFF");
          }
          else{
            $("#chk"+value).attr("checked","true");
            $("#chk"+value).prop("checked","true");
            $(tr).css("background-color","#BEDAE8");

          }
        })
      }
    </script>               
                   
                           
                        <!-- /.row -->
                    </section>

                         
                      
                    <section class="content">
                       
                      <!--div class="col-xs-12"-->
                        <div class="box">
                          <div class="box-header">
                          </div>
                           <?=$obj1->mostrar1()?>
                          <!-- /.box-header -->

                          <!-- /.box-body -->

                                  <button type="submit" class="btn btn-primary pull-right" name="guardar" data-dismiss="modal" style="background-image: url('img/azulG.png')";>Cerrar</button>
                        </div>

                            
                               
                            
                      <!--/div-->

                      <!-- /.col -->
                  
                    <!-- /.row -->
                </section>
</div>

</div>
</div>
</div>


<!-----------------------------------------------------------------------------------ASIGNAAAAAAAAAAAAAAAAAAAAAR------------------------------>
<div class="content-wrapper">
  <div class="modal modal-primary fade" id="modal-asignar">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class=" fa-danger">Agrupar </h4>
              </div>
               <div class="modal-body">
                <p> ¿Desea asignar los datos??&hellip;</p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-default"  data-dismiss="modal" onclick="addAgrup();">Asignar</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
      </div>



<!-- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Fin Asignar<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<-->




<div class="content-wrapper">
  <div class="modal modal-danger" id="modal-eliminarA">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4  color="FFFFFF">ADVERTENCIA</h4>
              </div>
               <div class="modal-body">
                <p> La confirmación eliminará todos los datos, ¿Desea eliminarlos?&hellip;</p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-default" data-dismiss="modal"  style="background-image: url('img/blanco.png')" onclick="deleteAgrupamiento();">Eliminar</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
      </div>



<div class="content-wrapper">
  <div class="modal modal-danger" id="modal-eliminar">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4  color="FFFFFF">ADVERTENCIA</h4>
              </div>
               <div class="modal-body">
                <p> La confirmación eliminará todos los datos, ¿Desea eliminarlos?&hellip;</p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-default" data-dismiss="modal"  style="background-image: url('img/blanco.png')" onclick="deleteUsuario();">Eliminar</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
      </div>






<div class="content-wrapper">
  <div class="modal modal-danger" id="modal-dange">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4  color="FFFFFF">ADVERTENCIA</h4>
              </div>
               <div class="modal-body">
                <p> La confirmación eliminará todos los datos, ¿Desea eliminarlos?&hellip;</p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-default" data-dismiss="modal"  style="background-image: url('img/blanco.png')" onclick="deleteGrupo();">Eliminar</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
      </div>
<script>
          function seleccionar(tr,value){
            $(function(){
              if($("#chk"+value).attr("checked") == "checked"){
                $("#chk"+value).prop('checked', false).removeAttr('checked');
                $(tr).css("background-color","#FFFFFF");
              }
              else{
                $("#chk"+value).attr("checked","true");
                $("#chk"+value).prop("checked","true");
                $(tr).css("background-color","#BEDAE8");

              }
            })
          }
        </script>
 
          <!-- /.modal-dialog -->

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="../../bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="../../bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="../../bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="../../bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false

    })
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
    $('#example3').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<script src="CrudGrupo.js"></script>


</body>
</html>
