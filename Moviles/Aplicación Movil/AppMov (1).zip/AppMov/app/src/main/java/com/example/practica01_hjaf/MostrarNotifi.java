package com.example.practica01_hjaf;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;

public class MostrarNotifi extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private ListView list;
    AdaptadorN adaptador;
    public static ArrayList<NotificacionN> empleado;

    String url = "https://apihjafbasededatos.000webhostapp.com/crud/mostrarNotifi.php";
    NotificacionN emplads;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar);

        list = findViewById(R.id.listado);
        mostrarDatos();
        //empleado.add(new Empleado("2","Juan","Perla","clav"));
        adaptador=new AdaptadorN(this,empleado);
        list.setAdapter(adaptador);

         list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                ProgressDialog progressDialog = new ProgressDialog(view.getContext());

                CharSequence[] dialogoItem = {"Ver detalles"};
                builder.setTitle(empleado.get(position).getTitulo());
                builder.setItems(dialogoItem, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        switch (i){
                            case 0:
                                Intent intento = new Intent(getApplicationContext(),VerNotificacion.class);
                                intento.putExtra("position",position);
                                startActivity(intento);
                                break;
                        }
                    }
                });
                builder.create().show();
            }
        });

    }

    public void mostrarDatos() {
        empleado = new ArrayList<NotificacionN>();
        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                empleado.clear();
                //Toast.makeText(mostrar.this, "Datos mostrados", Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String succes = jsonObject.getString("estatus"); //pasa saber si hay o no empleados


                    JSONArray jsonArray = jsonObject.getJSONArray("notificacion");

                    if (succes.equals("1")) {


                        for (int i = 0; i < jsonArray.length(); i++) {


                            JSONObject object = jsonArray.getJSONObject(i);
                            String idNotificacion = object.getString("idNotificacion");
                            String titulo = object.getString("titulo");
                            String descripcion = object.getString("descripcion");
                            String fecha = object.getString("fecha");
                            String grupo_idGrupo = object.getString("grupo_idGrupo");


                            emplads = new NotificacionN(idNotificacion, titulo, descripcion, fecha, grupo_idGrupo);
                            empleado.add(emplads);
                            adaptador.notifyDataSetChanged();

                        }
                        //Toast.makeText(MainActivity.this, "Datos guardados", Toast.LENGTH_LONG).show();
                    }
                    // Toast.makeText(MainActivity.this, "Datos no guardados", Toast.LENGTH_LONG).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MostrarNotifi.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        // Toast.makeText(MainActivity.this, "Datos no no guardados", Toast.LENGTH_LONG).show();
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);

    }



    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(MostrarNotifi.this, "El id es: "+empleado.get(position).idNotificacion, Toast.LENGTH_SHORT).show();
    }





    public void btnAgg(View view) {
       // startActivity(new Intent(getApplicationContext(), insertar.class));
    }

}
