package com.example.practica01_hjaf;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {

    EditText  tv_clave;
    Button btn_login;
    String usuario, clave;
    private ArrayList<String> lista = new ArrayList<String>();
    private Spinner spin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        spin =findViewById(R.id.spinner);
        String[] valores = {"Alumno", "Personal"};
        spin.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, valores));
        tv_clave=findViewById(R.id.tv_clave);
        btn_login=findViewById(R.id.btn_login);

        recuperarPreferencias();

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clave=tv_clave.getText().toString();
                if(spin.getSelectedItem()=="Alumno" && !clave.isEmpty()){
                    validarEstudiante("http://sistemas.upiiz.ipn.mx/isc/nopu/api/alumno.php");
                }else if(spin.getSelectedItem()=="Personal" && !clave.isEmpty()){
                    validarEmpleado("http://sistemas.upiiz.ipn.mx/isc/nopu/api/personal.php");
                }
                else{
                    Toast.makeText(Login.this, "No se permiten campos vacíos",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
    private void validarEstudiante(String url){
        url = String.format(url+"?boleta=%1$s",clave);
        Log.d("prueba",url);
        JsonObjectRequest jsObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null,new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response){
                int estado = 0;
                try {
                    estado = response.getInt("estado");
                    Log.d("prueba2", response.getString("mensaje"));
                    usuario = response.getString("nombre");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if(estado == 1){
                    guardarPreferencias();
                    Intent intent=new Intent(getApplicationContext(),NavigationDrawer.class);
                    startActivity(intent);
                    finish();
                }else{
                    Toast.makeText(Login.this,"No existe boleta introducida", Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Login.this,error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        }){

        };

        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(jsObjectRequest);
    }
    private void validarEmpleado(String url){
        url = String.format(url+"?numempleado=%1$s",clave);
        Log.d("prueba",url);
        JsonObjectRequest jsObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null,new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response){
                int estado = 0;
                try {
                    estado = response.getInt("estado");
                    usuario = response.getString("nombre");
                    Log.d("prueba2", response.getString("mensaje"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if(estado == 1){
                    guardarPreferencias();
                    Intent intent=new Intent(getApplicationContext(), NavigationDrawer.class);
                    startActivity(intent);
                    finish();
                }else{
                    Toast.makeText(Login.this,"No existe boleta introducida", Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Login.this,error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        }){

        };

        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(jsObjectRequest);
    }

    private void guardarPreferencias(){
        SharedPreferences preferences=getSharedPreferences("preferenciasLogin", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("usuario", usuario);
        editor.putString("clave",clave);
        editor.putBoolean("sesion", true);
        editor.commit();
    }

    private void recuperarPreferencias(){
        SharedPreferences preferences=getSharedPreferences("preferenciasLogin", Context.MODE_PRIVATE);

        tv_clave.setText(preferences.getString("clave",""));
    }

    private void darCliclk(){
        spin.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, lista);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(adapter);
    }
}