package com.example.practica01_hjaf;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class VerNotificacion extends AppCompatActivity{

    TextView tv_titulo, tv_descripcion;
    Button btn_regresar;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_notificacion);


        tv_titulo = findViewById(R.id.tv_titul);
        tv_descripcion = findViewById(R.id.tv_descripcionn);
        btn_regresar = findViewById(R.id.btn_volver);

        Intent intent = getIntent();
        position=intent.getExtras().getInt("position");

        Toast.makeText(VerNotificacion.this, "El id es: "+position, Toast.LENGTH_SHORT).show();

        tv_titulo.setText(MostrarNotifi.empleado.get(position).getTitulo());
        tv_descripcion.setText(MostrarNotifi.empleado.get(position).getDescripcion());

        btn_regresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentoo = new Intent(getApplicationContext(),MostrarNotifi.class);
                startActivity(intentoo);
            }
        });

    }

    public void actualizar(View view){

        final String nombre = tv_titulo.getText().toString();
        final String usuario = tv_descripcion.getText().toString();


        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Cargando....");
        progressDialog.show();

        StringRequest request = new StringRequest(Request.Method.POST, "https://apihjafbasededatos.000webhostapp.com/crud/actualizar.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(VerNotificacion.this, response, Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), MostrarNotifi.class));
                finish();
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(VerNotificacion.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        }){
            protected Map<String, String> getParams() throws AuthFailureError{
                Map<String, String> params =  new HashMap<String, String>();

                params.put("titulo", nombre);
                params.put("descripcion", usuario);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(VerNotificacion.this);
        requestQueue.add(request);

    }

}