package com.example.practica01_hjaf;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static android.content.ContentValues.TAG;

public class PushService extends FirebaseMessagingService {
    SharedPreferences preferences=getSharedPreferences("preferenciasLogin", Context.MODE_PRIVATE);
    String boleta = preferences.getString("clave","");
    String mensaje;
    String token;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        // TODO(developer): Handle FCM messages here.
        // Not getting messages here? See why this may be: https://goo.gl/39bRNJ
        /*
        Log.d(TAG, "From: " + remoteMessage.getFrom());

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());
        }

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
            mensaje = remoteMessage.getNotification().getBody();
        }

        String url="mensajes";
        url = String.format(url+"?boleta=%1$s",boleta);
        Log.d("prueba",url);
        JsonObjectRequest jsObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null,new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response){

            }

            public Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("mensaje", mensaje);
                return params;
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){

        };

        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(jsObjectRequest);


    }
    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);
        token = s;
        Log.d("NEW_TOKEN",s);
        String url = "sfbjsdhbfhjdsjhfbjd/edit_token.php";
        url = String.format(url+"?boleta=%1$s",boleta);
        Log.d("prueba",url);
        JsonObjectRequest jsObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null,new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response){

            }

            public Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("token", token);
                return params;
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){

        };

        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(jsObjectRequest);*/


    }

}
