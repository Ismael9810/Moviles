package com.example.practica01_hjaf;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Editar extends AppCompatActivity {

    EditText tv_nombre, tv_usuario, tv_clave, tv_id;
    Button btn_actualizar;
    int position;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar);

        tv_id = findViewById(R.id.tv_id);
        tv_nombre = findViewById(R.id.tv_nombre);
        tv_usuario = findViewById(R.id.tv_usuario);
        tv_clave = findViewById(R.id.tv_clave);
        //btn_actualizar = findViewById(R.id.btn_actualizar);

        Intent intent = getIntent();
        position=intent.getExtras().getInt("position");
/*
        tv_id.setText(MostrarNotifi.empleado.get(position).getId());
        tv_nombre.setText(MostrarNotifi.empleado.get(position).getNombre());
        tv_usuario.setText(MostrarNotifi.empleado.get(position).getUsuario());
        tv_clave.setText(MostrarNotifi.empleado.get(position).getClave());*/



    }

    public void actualizar(View view){
        final String id = tv_id.getText().toString();
        final String nombre = tv_nombre.getText().toString();
        final String usuario = tv_usuario.getText().toString();
        final String clave = tv_clave.getText().toString();


        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Cargando....");
        progressDialog.show();

        StringRequest request = new StringRequest(Request.Method.POST, "https://apihjafbasededatos.000webhostapp.com/crud/actualizar.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(Editar.this, response, Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), MostrarNotifi.class));
                finish();
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Editar.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        }){
            protected Map<String, String> getParams() throws AuthFailureError{
                Map<String, String> params =  new HashMap<String, String>();

                params.put("id",id);
                params.put("nombre", nombre);
                params.put("usuario", usuario);
                params.put("clave", clave);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(Editar.this);
        requestQueue.add(request);

    }
}