package com.example.practica01_hjaf;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.squareup.picasso.Picasso;

import java.util.List;

public class AdaptadorN extends ArrayAdapter<NotificacionN> {

    Context context;
    List<NotificacionN> arraylistaEmp;

    public AdaptadorN(@NonNull Context context, List<NotificacionN> arraylistaEmp) {
        super(context, R.layout.diseno_item,arraylistaEmp);

        this.context=context;
        this.arraylistaEmp= arraylistaEmp;
    }
    @Override
    public int getCount() {
        return this.arraylistaEmp.size();
    }


    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.diseno_item,null, true);

        TextView tv_nombre = view.findViewById(R.id.tv_nombrem);
        ImageView fotos= view.findViewById(R.id.imgFoto);

        tv_nombre.setText(" "+arraylistaEmp.get(position).getTitulo());

        return view;
    }
}
