package com.example.practica01_hjaf;

import java.util.Date;

public class NotificacionN {

    String idNotificacion, titulo, descripcion, grupo_idGrupo, fecha;

    public NotificacionN() {
    }

    public NotificacionN(String idNotificacion, String titulo, String descripcion, String fecha, String grupo_idGrupo) {
        this.idNotificacion = idNotificacion;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.fecha = fecha;
        this.grupo_idGrupo = grupo_idGrupo;
    }

    public String getIdNotificacion() {
        return idNotificacion;
    }

    public void setIdNotificacion(String idNotificacion) {
        this.idNotificacion = idNotificacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getGrupo_idGrupo() {
        return grupo_idGrupo;
    }

    public void setGrupo_idGrupo(String grupo_idGrupo) {
        this.grupo_idGrupo = grupo_idGrupo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
}
